<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: ModoAuth2
--------------------
Version: 1.0
 
A oAuth2 provider for MODx Revolution leveraging Brent Shaffer\'s  oauth2-server-php (https://github.com/bshaffer/oauth2-server-php).
',
    'changelog' => 'Changelog file for ModoAuth2 component.
 
ModoAuth 1.0
====================================
- oAuth2 provider in ModX that returns profile data once user is authenticated and access is granted to client.',
    'setup-options' => 'modoauth-1.0-beta9/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b1d31180c7bf043bf02251326cf3817a',
      'native_key' => 'modoauth',
      'filename' => 'modNamespace/c2d29478437a5e5d6fe6e345b36646f0.vehicle',
      'namespace' => 'modoauth',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9316c115c113dbc33523bdcb7fff0e1e',
      'native_key' => 1,
      'filename' => 'modCategory/9f1ae99454c968274c85c10e1027ba32.vehicle',
      'namespace' => 'modoauth',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5ef2aa043e6bca882a72c854bbf9b685',
      'native_key' => 'modoauth',
      'filename' => 'modMenu/880b8f398af68acefb8fa29325ffea28.vehicle',
      'namespace' => 'modoauth',
    ),
  ),
);
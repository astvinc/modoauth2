--------------------
Extra: ModoAuth2
--------------------
Version: 1.0
 
A oAuth2 provider for MODx Revolution leveraging Brent Shaffer's  oauth2-server-php (https://github.com/bshaffer/oauth2-server-php).

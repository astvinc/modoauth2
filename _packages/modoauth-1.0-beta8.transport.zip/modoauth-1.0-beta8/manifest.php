<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: ModoAuth2
--------------------
Version: 1.0
 
A oAuth2 provider for MODx Revolution leveraging Brent Shaffer\'s  oauth2-server-php (https://github.com/bshaffer/oauth2-server-php).
',
    'changelog' => 'Changelog file for ModoAuth2 component.
 
ModoAuth 1.0
====================================
- oAuth2 provider in ModX that returns profile data once user is authenticated and access is granted to client.',
    'setup-options' => 'modoauth-1.0-beta8/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9bddbdd018ff6c7cabb6fa140c7388cc',
      'native_key' => 'modoauth',
      'filename' => 'modNamespace/15995f8e749337e953dbee1df626529c.vehicle',
      'namespace' => 'modoauth',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b962ca76f05f9ff0e0d53478d1735274',
      'native_key' => 1,
      'filename' => 'modCategory/70d28d1fee9887245d65f806f3e635a0.vehicle',
      'namespace' => 'modoauth',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '8a3b80af90ef702dcfb67f6a46105437',
      'native_key' => 'modoauth',
      'filename' => 'modMenu/ccd16de47a5f3a191d524d568dbc678e.vehicle',
      'namespace' => 'modoauth',
    ),
  ),
);
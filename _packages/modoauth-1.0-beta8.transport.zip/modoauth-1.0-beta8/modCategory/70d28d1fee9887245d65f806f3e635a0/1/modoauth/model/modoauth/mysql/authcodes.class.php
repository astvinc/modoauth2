<?php
require_once (dirname(dirname(__FILE__)) . '/authcodes.class.php');
class AuthCodes_mysql extends AuthCodes {}
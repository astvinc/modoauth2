<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: ModoAuth2
--------------------
Version: 1.0
 
A oAuth2 provider for MODx Revolution leveraging Brent Shaffer\'s  oauth2-server-php (https://github.com/bshaffer/oauth2-server-php).
',
    'changelog' => 'Changelog file for ModoAuth2 component.
 
ModoAuth 1.0
====================================
- oAuth2 provider in ModX that returns profile data once user is authenticated and access is granted to client.',
    'setup-options' => 'modoauth-1.0-beta10/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'fbc410cabd61402472650528bd2ad823',
      'native_key' => 'modoauth',
      'filename' => 'modNamespace/bd9a59388859b095825b4def3c031b12.vehicle',
      'namespace' => 'modoauth',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e891117ca7563c67681cbbee1c00384a',
      'native_key' => 1,
      'filename' => 'modCategory/594e1cd168996380c7f6b13e7960cb12.vehicle',
      'namespace' => 'modoauth',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '28fe5843787d5e2327a16c43cee9b2ea',
      'native_key' => 'modoauth',
      'filename' => 'modMenu/b04fe711e5fedff6bd9a1842dc8f8f19.vehicle',
      'namespace' => 'modoauth',
    ),
  ),
);
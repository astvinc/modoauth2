<?php

/**
 * Interface for all OAuth2 Client Assertion Types
 *
 * @see OAuth2_CompatibilityInterface
 */
interface OAuth2_ClientAssertionTypeInterface extends OAuth2_CompatibilityInterface
{

}

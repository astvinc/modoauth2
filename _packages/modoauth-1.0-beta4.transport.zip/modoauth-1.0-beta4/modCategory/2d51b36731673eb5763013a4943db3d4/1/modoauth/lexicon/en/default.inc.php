<?php

$_lang['modoauth'] = 'Mod-oAuth';
$_lang['modoauth'] = 'Mod-oAuth';
$_lang['modoauth.desc'] = 'Manage your oAuth2 clients here.';
$_lang['modoauth.description'] = 'Description';
$_lang['modoauth.client_err_ae'] = 'A client with that ID already exists.';
$_lang['modoauth.client_err_nf'] = 'Client not found.';
$_lang['modoauth.client_err_ns'] = 'Client not specified.';
$_lang['modoauth.client_err_ns_name'] = 'Please specify a ID for the client.';
$_lang['modoauth.client_err_remove'] = 'An error occurred while trying to remove the client.';
$_lang['modoauth.client_err_save'] = 'An error occurred while trying to save the client.';
$_lang['modoauth.client_create'] = 'Create New Client';
$_lang['modoauth.client_remove'] = 'Remove Client';
$_lang['modoauth.client_remove_confirm'] = 'Are you sure you want to remove this client?';
$_lang['modoauth.client_update'] = 'Update Client';
$_lang['modoauth.location'] = 'Location';
$_lang['modoauth.management'] = 'Client Management';
$_lang['modoauth.management_desc'] = 'Manage your oAuth2 clients here. You can edit them by either double-clicking on the grid or right-clicking on the respective row.';
$_lang['modoauth.name'] = 'Name';
$_lang['modoauth.id'] = 'ID';
$_lang['modoauth.secret'] = 'Secret';
$_lang['modoauth.redirect'] = 'Redirect';
$_lang['modoauth.search...'] = 'Search...';

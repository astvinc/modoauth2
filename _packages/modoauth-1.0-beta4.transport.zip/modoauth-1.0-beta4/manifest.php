<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: ModoAuth2
--------------------
Version: 1.0
 
A oAuth2 provider for MODx Revolution leveraging Brent Shaffer\'s  oauth2-server-php (https://github.com/bshaffer/oauth2-server-php).
',
    'changelog' => 'Changelog file for ModoAuth2 component.
 
ModoAuth 1.0
====================================
- Initial attempt to create a oAuth2 provider in ModX',
    'setup-options' => 'modoauth-1.0-beta4/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f2a1e8a07d8720a4b0f914268dcb63a4',
      'native_key' => 'modoauth',
      'filename' => 'modNamespace/2af676712c807e2b6e26ca54dad3fb98.vehicle',
      'namespace' => 'modoauth',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a997189a8981453f886f43a477aa5828',
      'native_key' => 1,
      'filename' => 'modCategory/2d51b36731673eb5763013a4943db3d4.vehicle',
      'namespace' => 'modoauth',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b2ef98319728e566fe598c2d074263bb',
      'native_key' => 'modoauth',
      'filename' => 'modMenu/33387d53207cd1d3fd558d12de9a832a.vehicle',
      'namespace' => 'modoauth',
    ),
  ),
);
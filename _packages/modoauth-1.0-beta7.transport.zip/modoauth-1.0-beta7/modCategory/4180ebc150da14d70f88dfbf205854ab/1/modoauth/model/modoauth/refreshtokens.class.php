<?php
class RefreshTokens extends xPDOSimpleObject {}
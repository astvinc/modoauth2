<?php
require_once (dirname(dirname(__FILE__)) . '/tokens.class.php');
class Tokens_mysql extends Tokens {}
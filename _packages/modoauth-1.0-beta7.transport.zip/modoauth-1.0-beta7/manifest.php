<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '--------------------
Extra: ModoAuth2
--------------------
Version: 1.0
 
A oAuth2 provider for MODx Revolution leveraging Brent Shaffer\'s  oauth2-server-php (https://github.com/bshaffer/oauth2-server-php).
',
    'changelog' => 'Changelog file for ModoAuth2 component.
 
ModoAuth 1.0
====================================
- oAuth2 provider in ModX that returns profile data once user is authenticated and access is granted to client.',
    'setup-options' => 'modoauth-1.0-beta7/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '04a6be6a1f5e6e3e2ccc8e197a7fdac9',
      'native_key' => 'modoauth',
      'filename' => 'modNamespace/d90fdbaab6246744d2a6b6a178b79a68.vehicle',
      'namespace' => 'modoauth',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0106d57621d2893ba0ac55a29038828e',
      'native_key' => 1,
      'filename' => 'modCategory/4180ebc150da14d70f88dfbf205854ab.vehicle',
      'namespace' => 'modoauth',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd79f7f953b288454afbb1fd6a8a9631a',
      'native_key' => 'modoauth',
      'filename' => 'modMenu/08820258f30d5b0260dbb4380d79c2e7.vehicle',
      'namespace' => 'modoauth',
    ),
  ),
);